 var Product=require('../models/product');
var mongoose =require('mongoose');

mongoose.connect('mongodb://localhost:27017/doli', { useNewUrlParser: true });

 var products=[
     new Product({
         imagePath: 'https://rukminim1.flixcart.com/image/714/857/jgjq0sw0/backpack/b/y/w/laptop-black-dlod-20-backpack-dell-original-imaf4rkjckmq6h9d.jpeg?q=50',
         title:'DELL Laptop Bag',
         description:'Laptop (Black) 20 L Backpack  (Black)',
         price:958

     }),
     new Product({
        imagePath: 'https://rukminim1.flixcart.com/image/714/857/jnamvm80/laptop-bag/h/x/5/1100-hp01-laptop-backpack-hp-original-imaf4377mere2yny.jpeg?q=50',
        title:'HP Laptop Bag',
        description:'15.6 inch Expandable Laptop Backpack (Black) 20 L Backpack  (Black)',
        price:866

    }),
    new Product({
        imagePath:'https://rukminim1.flixcart.com/image/714/857/jsw3yq80/laptop-bag/h/x/u/15-6-inch-expandable-laptop-backpack-ca-001-laptop-backpack-original-imaf54xpzzsf5duc.jpeg?q=50',
        title:'LENOVO Laptop Bag',
        description:'15.6 inch Expandable Laptop Backpack 30 L Backpack  (Black)',
        price:820

    }),
    new Product({
        imagePath: 'https://images-na.ssl-images-amazon.com/images/I/61QaLbys24L._UY395_.jpg',
        title:'MAC Laptop Bag',
        description:'DailyObjects Hipster Lace Black Dreamcatcher On White Wood City Compact Messenger Bag for up to Laptop MacBook',
        price:1499

    }),
    new Product({
        imagePath: 'https://images-na.ssl-images-amazon.com/images/I/81Xg2EpBlZL._SL1500_.jpg',
        title:'ACER Laptop Bag',
        description:'Acer Original Backpack 15.6 Black Laptop Bag',
        price:729

    }),
    new Product({
        imagePath: 'https://rukminim1.flixcart.com/image/704/704/jlcmavk0/bags/laptop-backpack/m/x/m/asus-15-6-original-imaf8g6puz6fzvps.jpeg?q=70',
        title:'ASUS Laptop Bag',
        description:'Asus 15.6" Laptop Bag  (Black)',
        price: 520
    }),
 ];

 var done=0; 
 for(var i=0;i<products.length;i++)
 {
   products[i].save(function(err,result)
   {
       done++;
       if(done === products.length){
           exit();
       }
   });
 }
 function exit()
 {
 mongoose.disconnect();
 }